class Track < ActiveRecord::Base
  belongs_to :album
end
