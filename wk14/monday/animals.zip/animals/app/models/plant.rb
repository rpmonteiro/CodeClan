class Plant < ActiveRecord::Base
end
